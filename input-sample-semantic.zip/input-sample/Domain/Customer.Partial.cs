namespace App.Domain;

public partial class Customer
{
    public System.Collections.Generic.List<Order> RecentOrders { get; set; } = new();
}
