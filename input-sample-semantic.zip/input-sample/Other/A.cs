namespace App.Other;

public class A
{
    public string Marker => "OtherA";
}
