namespace App.Shared;

public class A
{
    public string Marker => "SharedA";
}
