namespace App.Domain;

public class OrderLine
{
    public int Sku { get; set; }
    public int Quantity { get; set; }
    public Money Price { get; set; } = new Money(0, "USD");

    public readonly struct Money
    {
        public decimal Amount { get; }
        public string Currency { get; }
        public Money(decimal amount, string currency)
        {
            Amount = amount;
            Currency = currency;
        }
    }
}

