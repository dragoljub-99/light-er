namespace App.Domain.Results;

public sealed class Result<T>
{
    public bool IsSuccess { get; }
    public T? Value { get; }

    private Result(bool ok, T? value)
    {
        IsSuccess = ok;
        Value = value;
    }

    public static Result<T> Ok(T value) => new Result<T>(true, value);
    public static Result<T> Fail() => new Result<T>(false, default);
}
