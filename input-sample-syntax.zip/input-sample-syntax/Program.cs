namespace App;

using App.Domain;
using App.Services;

public static class Program
{
    public static void Main(string[] args)
    {
        var service = new OrderService();
        _ = service.PlaceOrder(new Customer { Id = 1, Name = "Nidza" },
                               new Order { Id = 42, CustomerId = 1 });
    }
}
