namespace App.Services;

using App.Domain;
using App.Domain.Results;

public interface IOrderService
{
    Result<Order> PlaceOrder(App.Domain.Customer customer, Order order);
    Order? FindOrder(int id);
}
