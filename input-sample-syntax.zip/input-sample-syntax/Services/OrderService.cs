namespace App.Services;

using App.Abstractions;
using App.Domain;
using App.Domain.Results;
using System.Collections.Generic;

public class OrderService : IOrderService
{
    private IRepository<Order>? _repo;

    public List<Order> Cache { get; set; } = new();

    public OrderService() { }

    public Result<Order> PlaceOrder(Customer customer, Order order)
    {
        Cache.Add(order);
        return Result<Order>.Ok(order);
    }

    public Order? FindOrder(int id)
    {
        return null;
    }
}
