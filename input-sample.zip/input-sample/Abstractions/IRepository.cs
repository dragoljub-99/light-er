namespace App.Abstractions;

using System.Collections.Generic;

public interface IRepository<T>
{
    T? GetById(int id);
    IReadOnlyList<T> List();
    void Add(T entity);
}
