namespace App.Domain;

using System.Collections.Generic;

public partial class Customer
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
	public class Address
    {
        public string Street { get; set; } = "";
        public string City { get; set; } = "";
    }

    public List<Address> Addresses { get; set; } = new();
}
