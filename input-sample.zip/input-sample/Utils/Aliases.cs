using C = App.Domain.Customer;
using O = App.Domain.Order;

namespace App.Utils;

public class Aliases
{
    public C CustomerAlias { get; set; } = new();
    public O? LastOrder { get; set; }
}
