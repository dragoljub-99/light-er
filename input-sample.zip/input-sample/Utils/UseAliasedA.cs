using X = App.Shared.A;

namespace App.Utils;

public class UseAliasedA
{
    public X? Aliased { get; set; }
}
